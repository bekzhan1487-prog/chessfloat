package com.example.chessfloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.abs

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private lateinit var bubbleLp: WindowManager.LayoutParams
    private var panel: LinearLayout? = null
    private var bubble: TextView? = null
    private var panelShown = false
    private var bubbleShown = false
    private val alphas = floatArrayOf(1f, 0.85f, 0.7f, 0.55f)
    private var alphaIdx = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        buildWindows()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val channelId = "chessfloat"
        val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(channelId, "Шахматы", NotificationManager.IMPORTANCE_LOW)
        )
        val n: Notification = Notification.Builder(this, channelId)
            .setContentTitle("Шахматы: лучший ход")
            .setContentText("Окно открыто. Закрыть: кнопка ✕ в окне.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun buildWindows() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        val w = (dm.widthPixels * 0.9f).toInt()
        val h = (dm.heightPixels * 0.55f).toInt()

        lp = WindowManager.LayoutParams(
            w, h, type, WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL, PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (dm.widthPixels - w) / 2
        lp.y = dp(60)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        bubbleLp = WindowManager.LayoutParams(
            dp(56), dp(56), type,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        bubbleLp.gravity = Gravity.TOP or Gravity.START
        bubbleLp.x = dp(8)
        bubbleLp.y = dp(200)

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setBackgroundColor(Color.parseColor("#1b2625"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#2c3b39"))

        val title = TextView(this)
        title.text = "  ⠿  Тяни за полосу"
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
                result?.confirm()
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        val fade = Button(this)
        fade.text = "◐"
        fade.setOnClickListener {
            alphaIdx = (alphaIdx + 1) % alphas.size
            lp.alpha = alphas[alphaIdx]
            wm.updateViewLayout(container, lp)
        }
        val mini = Button(this)
        mini.text = "▾"
        mini.setOnClickListener { collapse() }
        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { stopSelf() }
        bar.addView(fade, LinearLayout.LayoutParams(dp(48), dp(44)))
        bar.addView(mini, LinearLayout.LayoutParams(dp(48), dp(44)))
        bar.addView(close, LinearLayout.LayoutParams(dp(48), dp(44)))

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(container, lp)
                }
            }
            true
        }

        val grip = TextView(this)
        grip.text = "◢  потяни, чтобы изменить размер  "
        grip.gravity = Gravity.END or Gravity.CENTER_VERTICAL
        grip.setTextColor(Color.parseColor("#93a5a2"))
        grip.textSize = 12f
        grip.setBackgroundColor(Color.parseColor("#2c3b39"))
        var gx = 0f; var gy = 0f; var gw = 0; var gh = 0
        grip.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { gx = e.rawX; gy = e.rawY; gw = lp.width; gh = lp.height }
                MotionEvent.ACTION_MOVE -> {
                    lp.width = (gw + (e.rawX - gx).toInt()).coerceIn(dp(220), dm.widthPixels)
                    lp.height = (gh + (e.rawY - gy).toInt()).coerceIn(dp(260), dm.heightPixels)
                    wm.updateViewLayout(container, lp)
                }
            }
            true
        }

        container.addView(bar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        container.addView(web, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        container.addView(grip, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, dp(34)))
        panel = container

        val b = TextView(this)
        b.text = "♞"
        b.textSize = 28f
        b.gravity = Gravity.CENTER
        b.setTextColor(Color.WHITE)
        val bg = GradientDrawable()
        bg.shape = GradientDrawable.OVAL
        bg.setColor(Color.parseColor("#c2461f"))
        b.background = bg
        var bx = 0f; var by = 0f; var box = 0; var boy = 0; var moved = false
        b.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    bx = e.rawX; by = e.rawY; box = bubbleLp.x; boy = bubbleLp.y; moved = false
                }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - bx
                    val dy = e.rawY - by
                    if (abs(dx) > dp(6) || abs(dy) > dp(6)) moved = true
                    bubbleLp.x = box + dx.toInt()
                    bubbleLp.y = boy + dy.toInt()
                    wm.updateViewLayout(b, bubbleLp)
                }
                MotionEvent.ACTION_UP -> { if (!moved) expand() }
            }
            true
        }
        bubble = b

        wm.addView(container, lp)
        panelShown = true
    }

    private fun collapse() {
        if (panelShown) { panel?.let { wm.removeView(it) }; panelShown = false }
        if (!bubbleShown) { bubble?.let { wm.addView(it, bubbleLp) }; bubbleShown = true }
    }

    private fun expand() {
        if (bubbleShown) { bubble?.let { wm.removeView(it) }; bubbleShown = false }
        if (!panelShown) { panel?.let { wm.addView(it, lp) }; panelShown = true }
    }

    override fun onDestroy() {
        if (panelShown) panel?.let { runCatching { wm.removeView(it) } }
        if (bubbleShown) bubble?.let { runCatching { wm.removeView(it) } }
        super.onDestroy()
    }
}
