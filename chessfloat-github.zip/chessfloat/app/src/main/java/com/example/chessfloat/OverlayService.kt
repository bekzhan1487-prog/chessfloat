package com.example.chessfloat

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.os.Build
import android.os.IBinder
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.webkit.JsResult
import android.webkit.WebChromeClient
import android.webkit.WebView
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast

class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private lateinit var lp: WindowManager.LayoutParams
    private var root: LinearLayout? = null
    private var collapsed = false

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        startAsForeground()
        showWindow()
    }

    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()

    private fun startAsForeground() {
        val channelId = "chessfloat"
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NOTIFICATION_SERVICE) as NotificationManager
            nm.createNotificationChannel(
                NotificationChannel(channelId, "Шахматы", NotificationManager.IMPORTANCE_LOW)
            )
        }
        val n: Notification = (if (Build.VERSION.SDK_INT >= 26)
            Notification.Builder(this, channelId) else Notification.Builder(this))
            .setContentTitle("Шахматы: лучший ход")
            .setContentText("Плавающее окно открыто. Закрыть: кнопка ✕ в окне.")
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .build()
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE)
        } else {
            startForeground(1, n)
        }
    }

    private fun showWindow() {
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val dm = resources.displayMetrics
        val w = (dm.widthPixels * 0.94f).toInt()
        val h = (dm.heightPixels * 0.62f).toInt()
        val type = WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
        lp = WindowManager.LayoutParams(
            w, h, type,
            WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        )
        lp.gravity = Gravity.TOP or Gravity.START
        lp.x = (dm.widthPixels - w) / 2
        lp.y = dp(80)
        lp.softInputMode = WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE

        val container = LinearLayout(this)
        container.orientation = LinearLayout.VERTICAL
        container.setBackgroundColor(Color.parseColor("#1b2625"))

        val bar = LinearLayout(this)
        bar.orientation = LinearLayout.HORIZONTAL
        bar.gravity = Gravity.CENTER_VERTICAL
        bar.setBackgroundColor(Color.parseColor("#2c3b39"))

        val title = TextView(this)
        title.text = "  ⠿  Тяни за эту полосу"
        title.setTextColor(Color.WHITE)
        title.textSize = 14f
        bar.addView(title, LinearLayout.LayoutParams(0, dp(44), 1f))

        val web = WebView(this)
        web.settings.javaScriptEnabled = true
        web.settings.domStorageEnabled = true
        web.webChromeClient = object : WebChromeClient() {
            override fun onJsAlert(
                view: WebView?, url: String?, message: String?, result: JsResult?
            ): Boolean {
                Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
                result?.confirm()
                return true
            }
        }
        web.loadUrl("file:///android_asset/index.html")

        val min = Button(this)
        min.text = "—"
        min.setOnClickListener {
            collapsed = !collapsed
            web.visibility = if (collapsed) View.GONE else View.VISIBLE
            lp.height = if (collapsed) WindowManager.LayoutParams.WRAP_CONTENT else h
            wm.updateViewLayout(container, lp)
        }
        val close = Button(this)
        close.text = "✕"
        close.setOnClickListener { stopSelf() }
        bar.addView(min, LinearLayout.LayoutParams(dp(56), dp(44)))
        bar.addView(close, LinearLayout.LayoutParams(dp(56), dp(44)))

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        title.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = lp.x; oy = lp.y }
                MotionEvent.ACTION_MOVE -> {
                    lp.x = ox + (e.rawX - sx).toInt()
                    lp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(container, lp)
                }
            }
            true
        }

        container.addView(bar, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT))
        container.addView(web, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f))
        root = container
        wm.addView(container, lp)
    }

    override fun onDestroy() {
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        super.onDestroy()
    }
}
